VIBE final single-file PWA prototype. Upload index.html to the root of the GitHub Pages repository.
